# RA-KG-PPO: Retrieval-Augmented Knowledge Graph PPO

完整的强化学习推荐系统实现，结合知识图谱增强和检索机制。

 **完整的PPO实现**: 包括GAE优势估计、PPO裁剪目标、价值函数优化
 **知识图谱增强**: 使用TransE预训练KG嵌入，捕捉物品语义关系
 **检索增强**: LSH-based候选生成，支持大规模物品空间
 **策略条件化**: 查询投影网络使候选生成适应当前策略状态
 **纯PyTorch实现**: 不依赖额外RL框架，易于理解和修改

## 快速开始

### 安装依赖

```bash
pip install -r requirements.txt
```

### 准备数据

```bash
python scripts/prepare_data.py --dataset amazon-book
```

### 快速测试

```bash
python test_training.py
```

### 完整训练

```bash
python train.py --dataset amazon-book --total-timesteps 100000
python train.py --dataset amazon-book --device cuda --total-timesteps 500000
```

## 架构

```
RA-KG-PPO
├── Data Layer (数据加载+KG嵌入) 
├── Model Layer (GRU+Actor+Critic) 
├── Retrieval Layer (LSH+候选生成) 
├── Environment Layer (MDP+奖励) 
└── Training Layer (PPO+GAE) 
```

## 测试结果

在amazon-book数据集上的快速测试：

```
Dataset: 24,915 items, 495,866 KG triples
Model: 198,913 parameters
Test: 13s for 1024 timesteps
Status: ✓ All components working
```

## 详细文档

[数据加载文档](docs/DATA_LOADING.md)
[实现总结](docs/IMPLEMENTATION_SUMMARY.md)

## Status

**完整实现**  | **测试通过**  | **Last Update**: 2025-12-20
