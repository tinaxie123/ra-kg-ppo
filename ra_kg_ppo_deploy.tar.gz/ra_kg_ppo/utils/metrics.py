"""
utils/metrics.py - 评估指标（完整版）
"""

import torch
import numpy as np
import pandas as pd
from typing import Dict, List


def compute_recall_at_k(pred_items: List[int], gt_items: List[int], k: int) -> float:
    """
    Recall@K = |预测的前K个 ∩ 真实喜欢的| / |真实喜欢的|
    
    Args:
        pred_items: 预测的物品列表（按分数排序）
        gt_items: 真实喜欢的物品列表
        k: Top-K
    
    Returns:
        recall值
    """
    pred_set = set(pred_items[:k])
    gt_set = set(gt_items)
    
    if len(gt_set) == 0:
        return 0.0
    
    return len(pred_set & gt_set) / len(gt_set)


def compute_ndcg_at_k(pred_items: List[int], gt_items: List[int], k: int) -> float:
    """
    NDCG@K: 归一化折损累积增益
    
    Args:
        pred_items: 预测的物品列表
        gt_items: 真实喜欢的物品列表
        k: Top-K
    
    Returns:
        NDCG值
    """
    pred_items = pred_items[:k]
    gt_set = set(gt_items)
    
    # 计算DCG
    dcg = 0.0
    for i, item in enumerate(pred_items):
        if item in gt_set:
            dcg += 1.0 / np.log2(i + 2)  # i+2因为索引从0开始
    
    # 计算理想DCG
    idcg = sum(1.0 / np.log2(i + 2) for i in range(min(len(gt_items), k)))
    
    if idcg == 0:
        return 0.0
    
    return dcg / idcg


def compute_hit_ratio_at_k(pred_items: List[int], gt_items: List[int], k: int) -> float:
    """
    Hit Ratio@K: 预测的前K个中是否包含至少一个真实物品
    
    Args:
        pred_items: 预测的物品列表
        gt_items: 真实喜欢的物品列表
        k: Top-K
    
    Returns:
        1.0 (命中) 或 0.0 (未命中)
    """
    pred_set = set(pred_items[:k])
    gt_set = set(gt_items)
    
    return 1.0 if len(pred_set & gt_set) > 0 else 0.0


def compute_precision_at_k(pred_items: List[int], gt_items: List[int], k: int) -> float:
    """
    Precision@K = |预测的前K个 ∩ 真实喜欢的| / K
    
    Args:
        pred_items: 预测的物品列表
        gt_items: 真实喜欢的物品列表
        k: Top-K
    
    Returns:
        precision值
    """
    pred_set = set(pred_items[:k])
    gt_set = set(gt_items)
    
    return len(pred_set & gt_set) / k


def evaluate_ranking(pred_items: List[int], gt_items: List[int], 
                     k_list: List[int] = [10, 20, 50]) -> Dict[str, float]:
    """
    计算多个排序指标
    
    Args:
        pred_items: 预测的物品列表（按分数降序）
        gt_items: 真实喜欢的物品列表
        k_list: 要计算的K值列表
    
    Returns:
        指标字典
    """
    metrics = {}
    
    for k in k_list:
        metrics[f'Recall@{k}'] = compute_recall_at_k(pred_items, gt_items, k)
        metrics[f'NDCG@{k}'] = compute_ndcg_at_k(pred_items, gt_items, k)
        metrics[f'Hit@{k}'] = compute_hit_ratio_at_k(pred_items, gt_items, k)
        metrics[f'Precision@{k}'] = compute_precision_at_k(pred_items, gt_items, k)
    
    return metrics


def evaluate_policy(
    policy,
    test_users: Dict[int, List[int]],
    item_embeddings: torch.Tensor,
    kg_embeddings: torch.Tensor,
    k_list: List[int] = [10, 20, 50],
    device: str = 'cpu'
) -> Dict[str, float]:
    """
    评估推荐策略
    
    Args:
        policy: RA-KG-PPO策略
        test_users: 测试用户序列
        item_embeddings: 物品嵌入
        kg_embeddings: KG嵌入
        k_list: 评估的K值列表
        device: 设备
    
    Returns:
        {
            'Recall@10': float,
            'Recall@20': float,
            'NDCG@10': float,
            'NDCG@20': float,
            ...
        }
    """
    
    policy.eval()
    
    metrics = {f'Recall@{k}': [] for k in k_list}
    metrics.update({f'NDCG@{k}': [] for k in k_list})
    metrics.update({f'Hit@{k}': [] for k in k_list})
    
    with torch.no_grad():
        for user_id, sequence in test_users.items():
            if len(sequence) < 5:
                continue
            
            # 用前面的作为历史，最后几个作为ground truth
            history = sequence[:-3]
            gt_items = sequence[-3:]
            
            if len(history) == 0:
                continue
            
            # 构造输入
            history_ids = torch.tensor(history[-50:], device=device).unsqueeze(0)
            history_embs = item_embeddings[history_ids]
            lengths = torch.tensor([len(history_ids[0])], device=device)
            
            # 生成推荐
            hidden = policy.actor_critic.get_hidden_state(history_embs, lengths)
            query, cand_ids, cand_embs = policy.candidate_generator(hidden)
            
            # 计算分数
            logits = policy.actor_critic.actor.compute_action_logits(query, cand_embs)
            scores, indices = torch.sort(logits[0], descending=True)
            
            # 映射回真实物品ID
            pred_items = cand_ids[0][indices].cpu().tolist()
            
            # 计算指标
            for k in k_list:
                recall = compute_recall_at_k(pred_items, gt_items, k)
                ndcg = compute_ndcg_at_k(pred_items, gt_items, k)
                hit = compute_hit_ratio_at_k(pred_items, gt_items, k)
                
                metrics[f'Recall@{k}'].append(recall)
                metrics[f'NDCG@{k}'].append(ndcg)
                metrics[f'Hit@{k}'].append(hit)
    
    # 求平均
    for key in metrics:
        if len(metrics[key]) > 0:
            metrics[key] = np.mean(metrics[key])
        else:
            metrics[key] = 0.0
    
    return metrics


def evaluate_baselines(
    test_users: Dict,
    item_embeddings: torch.Tensor,
    baseline_models: Dict,
    k_list: List[int] = [10, 20]
) -> pd.DataFrame:
    """
    评估所有基线模型
    
    Args:
        test_users: 测试用户序列
        item_embeddings: 物品嵌入
        baseline_models: {
            'KGAT': model,
            'SASRec': model,
            'TPGR': model,
            ...
        }
        k_list: 评估的K值列表
    
    Returns:
        对比表格 DataFrame
    """
    
    results = []
    
    for model_name, model in baseline_models.items():
        print(f"Evaluating {model_name}...")
        
        metrics = evaluate_policy(
            policy=model,
            test_users=test_users,
            item_embeddings=item_embeddings,
            kg_embeddings=None,  # 根据模型调整
            k_list=k_list
        )
        
        row = {'Model': model_name}
        row.update(metrics)
        results.append(row)
    
    df = pd.DataFrame(results)
    
    print("\n" + "="*80)
    print("BASELINE COMPARISON")
    print("="*80)
    print(df.to_string(index=False))
    
    return df


# ============ 测试代码 ============

if __name__ == '__main__':
    print("Testing metrics...")
    
    # 测试基础指标
    pred = [1, 5, 3, 8, 2, 7, 4, 9, 6]
    gt = [1, 3, 5]
    
    metrics = evaluate_ranking(pred, gt, k_list=[5, 10])
    
    print("\n指标计算测试:")
    for name, value in metrics.items():
        print(f"  {name}: {value:.3f}")
    
    print("\n✓ 所有指标计算正常!")